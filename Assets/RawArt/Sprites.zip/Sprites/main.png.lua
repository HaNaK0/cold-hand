local sheet = {}

sheet.path = nil

local faceOffset = 27;
local squareSize = 16;

--(13 + 1) * 1 + 2,

sheet.sprites = {}

-- numbers
local names = {"number_1", "number_2", "number_3", "number_4", "number_5", "number_6", "number_7", "number_8", "number_9", "number_0"}

local startX = 2;
local startY = 2;
local width = 13;
local height = 23;

local spacing = 1;

for i = 1, 10 do
    sheet.sprites[i] = {
        name = names[i],
        x = startX + (width + spacing) * (i - 1),
        y = startY,
        width = width,
        height = height
    }
end

-- face
local names = {"happyFace_up", "happyFace_pressed", "oohFace", "winFace", "deadFace"}

local startX = 2;
local startY = 26;
local width = 26;
local height = 26;

local spacing = 1;

for i = 1, 5 do
    sheet.sprites[10 + i] = {
        name = names[i],
        x = startX + (width + spacing) * (i - 1),
        y = startY,
        width = width,
        height = height
    }
end

-- squares
local names = {"sqaure", "square_empty", "square_withFlag", "square_questionMark", "square_openQuestionMark", "square_mine", "square_mineExploded", "square_noMine", 
"square_1", "square_2", "square_3", "square_4", "square_5", "square_6", "square_7", "square_8"}

local startX = 2;
local startY = 53;
local width = 16;
local height = 16;

local spacing = 1;

local rows = 2;
local rowWidth = 8;

for i = 1, rows do
    for j = 1, rowWidth do
        local index = rowWidth * (i - 1) + j;
        sheet.sprites[15 + index] = {
            name = names[index],
            x = startX + (width + spacing) * (j - 1),
            y = startY + (height + spacing) * (i - 1),
            width = width,
            height = height
        }
    end
end
return sheet